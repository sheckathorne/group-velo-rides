import { RideList } from "@/components/ride-list"

export default function HomePage() {
  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-6">Upcoming Group Rides</h1>
      <RideList />
    </div>
  )
}
